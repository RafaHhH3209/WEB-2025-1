document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Evitar que el formulario se envíe por defecto
  
    // Obtener los valores de usuario y contraseña
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
  
    // Validar que el usuario y la contraseña sean correctos
    if (username === "admin" && password === "123") {
      alert("¡Login exitoso!");
      window.location.href = "home.html"; // Redirigir a otra página si es exitoso
    } else {
      document.getElementById("error-message").textContent = "Usuario o contraseña incorrectos";
    }
  });
  