   // Función para cerrar el modal de mensaje
   function closeMessageModal() {
    document.getElementById('messageModal').style.display = 'none';
}

// Función para mostrar el modal de mensaje
function showMessageModal() {
    document.getElementById('messageModal').style.display = 'block';
}

// Control de inicio de sesión
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('error-message');
    
    // Validación
    if (username === 'admin' && password === '1234') {
        // Mostrar el mensaje de éxito en un modal
        showMessageModal();
        // Opcionalmente, redirigir a otra página
        setTimeout(function() {
            window.location.href = '';  
        }, 2000);  // Redirige después de 2 segundos
    } else {
        errorMessage.style.display = 'block';
    }
});