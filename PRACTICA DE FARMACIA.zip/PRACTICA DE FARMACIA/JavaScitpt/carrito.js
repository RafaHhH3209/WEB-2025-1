let contadorCarrito = 0;

function agregarAlCarrito() {
    contadorCarrito++;
    document.getElementById("contador").innerText = contadorCarrito;
    document.getElementById("modal").style.display = "flex";
}

function cerrarModal() {
    document.getElementById("modal").style.display = "none";
}

let currentIndex = 0;

function moverCarrusel(direction) {
  const carrusel = document.getElementById("carrusel");
  const totalItems = carrusel.children.length;
  
  // 5 productos visibles
  const visibleItems = 5;
  
  currentIndex += direction;
  if (currentIndex < 0) currentIndex = totalItems - visibleItems;
  if (currentIndex >= totalItems) currentIndex = 0;

  // Desplazamos el carrusel
  carrusel.style.transform = `translateX(-${currentIndex * (100 / visibleItems)}%)`;
}